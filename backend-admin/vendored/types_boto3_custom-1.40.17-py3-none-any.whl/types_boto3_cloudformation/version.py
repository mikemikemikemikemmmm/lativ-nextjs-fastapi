"""
Source of truth for version.

Copyright 2025 Vlad Emelianov
"""

__version__ = "1.40.17"
